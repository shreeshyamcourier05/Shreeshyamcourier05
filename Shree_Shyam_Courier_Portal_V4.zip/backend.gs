const ADMIN_PASSWORD = 'CHANGE_THIS_PASSWORD';
const SS = SpreadsheetApp.getActiveSpreadsheet();

function setup() {
  const sh = getSheet_('Shipments', ['AWB','Customer','From','To','Courier','Status','Cost','Sell','History','Updated']);
  const bk = getSheet_('Bookings', ['ID','Sender','Receiver','Destination','Weight','Service','Contents','Date']);
  return 'Setup complete';
}
function getSheet_(name, headers){
  let sh = SS.getSheetByName(name);
  if(!sh) sh = SS.insertSheet(name);
  if(sh.getLastRow()===0) sh.appendRow(headers);
  return sh;
}
function json_(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}
function rows_(sh){
  const v=sh.getDataRange().getValues(); if(v.length<2)return [];
  const h=v[0]; return v.slice(1).filter(r=>r.join('')!=='').map(r=>Object.fromEntries(h.map((k,i)=>[k,r[i]])));
}
function doGet(e){
  setup(); const p=e.parameter||{}; const action=p.action||'health';
  if(action==='track'){
    const awb=(p.awb||'').trim().toUpperCase();
    const s=rows_(SS.getSheetByName('Shipments')).find(x=>String(x.AWB).toUpperCase()===awb);
    return json_({ok:true,shipment:s||null});
  }
  if(action==='shipments') return json_({ok:true,shipments:rows_(SS.getSheetByName('Shipments'))});
  if(action==='bookings') return json_({ok:true,bookings:rows_(SS.getSheetByName('Bookings'))});
  return json_({ok:true,message:'Shree Shyam Courier backend is running'});
}
function doPost(e){
  setup(); let p={}; try{p=JSON.parse(e.postData.contents||'{}')}catch(err){return json_({ok:false,error:'Invalid JSON'});}
  if(p.action==='adminLogin') return json_({ok:p.password===ADMIN_PASSWORD});
  if(p.action==='saveShipment'){
    if(p.password!==ADMIN_PASSWORD)return json_({ok:false,error:'Unauthorized'});
    const sh=SS.getSheetByName('Shipments'); const all=rows_(sh); const awb=String(p.shipment.awb||'').trim().toUpperCase();
    if(!awb)return json_({ok:false,error:'AWB required'});
    const idx=all.findIndex(x=>String(x.AWB).toUpperCase()===awb); const hist=Array.isArray(p.shipment.history)?p.shipment.history:[p.shipment.status];
    const row=[awb,p.shipment.customer||'',p.shipment.from||'',p.shipment.to||'',p.shipment.courier||'',p.shipment.status||'Booked',Number(p.shipment.cost||0),Number(p.shipment.sell||0),hist.join(' | '),new Date()];
    if(idx>=0) sh.getRange(idx+2,1,1,row.length).setValues([row]); else sh.appendRow(row);
    return json_({ok:true});
  }
  if(p.action==='saveBooking'){
    const b=p.booking||{}; const sh=SS.getSheetByName('Bookings'); const id='BK'+Date.now().toString().slice(-8);
    sh.appendRow([id,b.sender||'',b.receiver||'',b.destination||'',b.weight||'',b.service||'',b.contents||'',new Date()]);
    return json_({ok:true,id});
  }
  return json_({ok:false,error:'Unknown action'});
}
